APRIL — Academic Personal Research & Intelligence Link

GitHub Pages upload package.
- index.html is the complete website (the logo is embedded).
- No build step or external libraries are required.

Before publishing:
- Review the HTML for any personal information you do not want public.
- APRIL stores each visitor's information in that visitor's own browser localStorage.
- The built-in device password is a convenience lock, not secure authentication.
